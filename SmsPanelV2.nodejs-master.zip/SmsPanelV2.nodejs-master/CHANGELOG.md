# Changelog

All notable changes to `Smsir` will be documented in this file

## 1.0.0 - 2022-22-02

- initial release

## 1.2

- support older versions of nodejs
